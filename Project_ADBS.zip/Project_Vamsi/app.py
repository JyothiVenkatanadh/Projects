from flask import Flask, request, jsonify, render_template, redirect, session
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "your_secret_key"

# Database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="library_db"
)
cursor = db.cursor(dictionary=True)


# Route: Dashboard Page (Redirects to after login)
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('dashboard.html', username=session.get('username'), role=session.get('role'))


# Route: Home Page (Role-Based Navigation)
@app.route('/')
def home():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('index.html', username=session.get('username'), role=session.get('role'))


# Route: Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            return "Username and password are required.", 400

        cursor.execute("SELECT * FROM Users WHERE username = %s", (username,))
        user = cursor.fetchone()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['user_id']
            session['username'] = user['username']
            session['role'] = user['role']
            return redirect('/dashboard')
        else:
            return "Invalid username or password.", 401

    return render_template('login.html')


# Route: Register
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')

        if not username or not password or not role:
            return "All fields (username, password, role) are required.", 400

        if role not in ['admin', 'member']:
            return "Invalid role. Please select either 'admin' or 'member'.", 400

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')

        try:
            cursor.execute(
                "INSERT INTO Users (username, password, role) VALUES (%s, %s, %s)",
                (username, hashed_password, role)
            )
            db.commit()
            return redirect('/login')
        except Exception as e:
            db.rollback()
            return f"Registration failed: {str(e)}", 400

    return render_template('register.html')


# Route: Logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')


# Route: View Books Page
@app.route('/view_books_page')
def view_books_page():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('view_books.html', username=session.get('username'))


# CRUD Routes for Books
@app.route('/add_book', methods=['POST'])
def add_book():
    if 'user_id' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized. Only admins can add books.'}), 401

    data = request.json
    if not data or not all(key in data for key in ['title', 'author', 'genre']):
        return jsonify({'error': 'Title, author, and genre are required.'}), 400

    try:
        cursor.execute(
            "INSERT INTO Books (title, author, genre, is_available) VALUES (%s, %s, %s, TRUE)",
            (data['title'], data['author'], data['genre'])
        )
        db.commit()
        return jsonify({'message': 'Book added successfully!'}), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/view_books', methods=['GET'])
def view_books():
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized. Please log in to view books.'}), 401

    try:
        cursor.execute("SELECT * FROM Books")
        books = cursor.fetchall()
        return jsonify(books), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/update_book/<int:book_id>', methods=['POST'])
def update_book(book_id):
    if 'user_id' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized. Only admins can update books.'}), 401

    data = request.json
    if not data or not all(key in data for key in ['title', 'author', 'genre']):
        return jsonify({'error': 'Title, author, and genre are required for updating.'}), 400

    try:
        cursor.execute(
            "UPDATE Books SET title = %s, author = %s, genre = %s WHERE book_id = %s",
            (data['title'], data['author'], data['genre'], book_id)
        )
        db.commit()
        return jsonify({'message': 'Book updated successfully!'}), 200
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/delete_book/<int:book_id>', methods=['POST'])
def delete_book(book_id):
    if 'user_id' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized. Only admins can delete books.'}), 401

    try:
        cursor.execute("DELETE FROM Books WHERE book_id = %s", (book_id,))
        db.commit()
        return jsonify({'message': 'Book deleted successfully!'}), 200
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)